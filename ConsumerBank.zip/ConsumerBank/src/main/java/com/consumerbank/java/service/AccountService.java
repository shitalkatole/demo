package com.consumerbank.java.service;

public interface AccountService {

}
