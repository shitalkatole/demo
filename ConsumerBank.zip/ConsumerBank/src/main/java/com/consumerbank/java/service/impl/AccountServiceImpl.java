package com.consumerbank.java.service.impl;

public class AccountServiceImpl {

}
