package com.consumerbank.java.service;

public interface TransactionService {

}
