package com.consumerbank.java.repo;

public interface TransactionRepository {

}
